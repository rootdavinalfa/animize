package ml.dvnlabs.animize;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class animlist_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animlist_activity);
    }
}
